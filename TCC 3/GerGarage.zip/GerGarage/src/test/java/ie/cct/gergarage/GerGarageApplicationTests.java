package ie.cct.gergarage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerGarageApplicationTests {

	@Test
	void contextLoads() {
	}

}
